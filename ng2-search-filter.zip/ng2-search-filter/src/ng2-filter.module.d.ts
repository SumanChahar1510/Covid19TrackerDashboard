import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './ng2-filter.pipe';
export declare class Ng2SearchPipeModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<Ng2SearchPipeModule, [typeof ɵngcc1.Ng2SearchPipe], never, [typeof ɵngcc1.Ng2SearchPipe]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<Ng2SearchPipeModule>;
}

//# sourceMappingURL=ng2-filter.module.d.ts.map